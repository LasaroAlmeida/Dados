/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_oo;

/**
 *
 * @author ice
 */
public class Romance extends Filme {
   
    public Romance(String nome, int fx_etaria, boolean alugado, float preco, int copias_filme) {
        super(nome,fx_etaria,alugado,preco,copias_filme);

    }   
}
