/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_oo;

/**
 *
 * @author ice
 */
public class Fornecedor extends Pessoa{
    private String cnpj;// talvez criar lista de pedidos 
    int idFornecedor=0;
    static int contadorFornecedor=0;
    float precoremessa;
    int qtd;
    public Paga p;
    
    public int getIdFornecedor() {
        return idFornecedor;
    }
    
    public Fornecedor(String nome, String telefone, String endereco, String Cnpj,int qtd,float precoremessa) {
        super(nome, telefone, endereco);
        this.cnpj=Cnpj;
        this.idFornecedor=contadorFornecedor;
        this.qtd=qtd;
        this.precoremessa=precoremessa;
        contadorFornecedor++;
    }
    public float getRemessa()
    {
        return precoremessa;
    }
    public int getQtd()
    {
        return qtd;
    }
    public void pagarFornecedor()
    {
        p.pagarFornecedor(qtd, precoremessa);
    }
}
