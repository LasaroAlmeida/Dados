package trabalho_oo;

public class Terror extends Filme {
   
    public Terror(String nome, int fx_etaria, boolean alugado, float preco, int copias_filme) {
        super(nome,fx_etaria,alugado,preco,copias_filme);

    }   
}
