/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_oo;

/**
 *
 * @author ice
 */
public class Funcionário extends Pessoa {
    private String cargo;
    private float salario;
    int idFuncionario=0;
    static int contadorFuncionario=0;

    public void paga(){
        contaBancaria-=salario;
    }
    public int getIdFuncionario() {
        return idFuncionario;
    }
    public Funcionário(String nome, String telefone, String endereco, String cargo, float salario) {
        super(nome, telefone, endereco);
        this.cargo=cargo;
        this.salario=salario;
        this.idFuncionario=contadorFuncionario;
        contadorFuncionario++;
    }
    
}
