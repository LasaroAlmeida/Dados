/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_oo;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;



/**
 *
 * @author Lasaro Almeida
 */
public class Locadora {
   private static List<Filme> lFilme = new ArrayList<>();
   private static List<Cliente> lCliente =  new ArrayList<>();
   private static List<Funcionário> lFuncionario = new ArrayList<>();
   private static List<Fornecedor> lFornecedor = new ArrayList<>();
   private static List<Aluguel> lAluguel = new ArrayList<>();
   public Float contaBancaria;
   public Locadora(){};
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       FileWriter writefile =null;
        /*GSONObject objetoJson = new GSONObject();*/
        Filme f2;
        f2 = new Terror("Lasaro",18,true,45.4f,10);
        Cliente c1 = new Cliente("marcos",18,"22554488","cpf----","Rua tal");
         //System.out.println(c2.getNome());
        lCliente.add(c1.getIdCliente(),c1);
        lFilme.add(0,f2);
        Aluguel a1 = new Aluguel(lCliente.get(0),lFilme.get(0),"01/01/01","04/01/01"); 
        
}
} 