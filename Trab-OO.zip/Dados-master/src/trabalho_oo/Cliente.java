
package trabalho_oo;

/**
 *
 * @author Lasaro Almeida
 */
public class Cliente extends Pessoa {
    private int idade;
    private String cpf;

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
    public Cliente(String nome, int idade, String telefone, String cpf, String endereco) {
        super(nome,telefone,endereco);
        this.idade = idade;
        this.cpf = cpf;
        
    }
    
}
