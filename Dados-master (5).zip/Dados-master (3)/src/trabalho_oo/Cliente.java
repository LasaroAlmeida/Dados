
package trabalho_oo;

/**
 *
 * @author Lasaro Almeida
 */
public class Cliente extends Pessoa {
    private int idade;
    private String cpf;
      int idCliente=0;
      static int contadorCliente=0;

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public int getIdCliente() {
        return idCliente;
    }
    
    public Cliente(String nome, int idade, String telefone, String cpf, String endereco) {
        super(nome,telefone,endereco);
        this.idade = idade;
        this.cpf = cpf;
        this.idCliente=contadorCliente;
        contadorCliente++;
        
    }
}
