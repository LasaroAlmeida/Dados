/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_oo;

/**
 *
 * @author ice
 */
public class Pagamentos implements Paga {

    private float contaBancaria;

    /**
     *
     * @param val
     */
    @Override
    public void pagarFilme(float val) {
        contaBancaria += val;
    }
    @Override
    public void pagarFuncionario(float salario)
    {
        contaBancaria -=salario;
    }
    @Override
    public void pagarFornecedor(int qtd,float custoremessa)
    {
        contaBancaria-=qtd*custoremessa;
    }
}
