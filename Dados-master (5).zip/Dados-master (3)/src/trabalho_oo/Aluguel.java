/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_oo;

import java.util.Date;

/**
 *
 * @author Lasaro Almeida
 */
public class Aluguel extends Locadora {
    private Cliente client;
    private Filme film;
    private String data;
    private String data_devolucao;
    public Paga p;

 
    public Aluguel(Cliente client, Filme film,String data, String data_devolucao) {
        this.client = client;
        this.film = film;
        this.data = data;
        this.data_devolucao = data_devolucao;
        film.setAlugado(true);
    }
    
    public void pagaAluguel(boolean opcao){
        if(opcao==true)
    {
        p.pagarFilme(film.getPreco());
    }

        film.setAlugado(false);
    }
    public Cliente getClient() {
        return client;
    }

    public Filme getFilm() {
        return film;
    }

    public String getData() {
        return data;
    }

    public String getData_devolucao() {
        return data_devolucao;
    }   
}
