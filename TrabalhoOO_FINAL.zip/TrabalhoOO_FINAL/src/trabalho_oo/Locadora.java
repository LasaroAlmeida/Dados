/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_oo;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;



/**
 *
 * @author Lasaro Almeida
 */
public class Locadora {
   public static List<Filme> lFilme = new ArrayList<>();
   public static List<Cliente> lCliente =  new ArrayList<>();
   public static List<Funcionário> lFuncionario = new ArrayList<>();
   public static List<Fornecedor> lFornecedor = new ArrayList<>();
   public static List<Aluguel> lAluguel = new ArrayList<>();
   public Paga ab;
   public Locadora(){};
    /**
     * @param args the command line arguments
     */
    
} 