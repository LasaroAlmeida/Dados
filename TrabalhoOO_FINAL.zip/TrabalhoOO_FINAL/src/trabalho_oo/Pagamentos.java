
package trabalho_oo;

/**
 *
 * @author ice
 */
public class Pagamentos implements Paga {

    private static float contaBancaria;

    public float getContaBancaria() {
        return contaBancaria;
    }

    public void setContaBancaria(float contaBancaria) {
        this.contaBancaria = contaBancaria;
    }

    /**
     *
     * @param val
     */
    @Override
    public void pagarFilme(float val) {
        contaBancaria += val;
    }
    @Override
    public void pagarFuncionario(float salario)
    {
        contaBancaria -=salario;
    }
    @Override
    public void pagarFornecedor(int qtd,float custoremessa)
    {
        contaBancaria-=qtd*custoremessa;
    }
}
