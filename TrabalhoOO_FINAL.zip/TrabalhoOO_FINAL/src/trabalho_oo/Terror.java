package trabalho_oo;

public class Terror extends Filme {
   
    public Terror(String nome, int fx_etaria, float preco, int copias_filme) {
        super(nome,fx_etaria,preco,copias_filme);

    }   

}
